""" python Script to parse all cbcs results of pesit south sem3"""
from bs4 import BeautifulSoup
import urllib2
import time

def url_generator(branch):
    
    urlstrings = []
    for i in range(1,10):
        urlstrings.append("http://result.vtu.ac.in/cbcs_results2017.aspx?usn=1pe15"+branch+ str("00"+str(i))+"&sem=3")
    
    for i in range(10,100) :
        urlstrings.append("http://result.vtu.ac.in/cbcs_results2017.aspx?usn=1pe15"+branch+ str("0"+str(i))+"&sem=3")

    for i in range(100,190):
        urlstrings.append("http://result.vtu.ac.in/cbcs_results2017.aspx?usn=1pe15"+branch+ str(i)+"&sem=3")
        
  
    return urlstrings


def parser(soup,resultfile,parsablerf):
    try:
        tag= soup.select("#txtName")
        for i in tag :
          # i is a tag
          p=i['value']
          resultfile.write(p+(30-len(str(p)))*" ")
          parsablerf.write(p+",")
    
          print i['value']+' '+'-',
          
    
        tag2= soup.select("#txtUSN")
        for i in tag2 :
          # i is a tag
          p=i['value']
          resultfile.write(p+"\t")
          parsablerf.write(p+",")
    
          print i['value']+' '+'-',
    
    
        tag4= soup.select("#txtGP1")
        for i in tag4 :#math
          # i is a tag
          p=i['value']
          resultfile.write(p+"\t")
          parsablerf.write(p+",")
    
          print i['value']+' '+'-',
    
    
        tag5= soup.select("#txtGP2")
        for i in tag5 :#chem
          # i is a tag
          p=i['value']
          resultfile.write(p+"\t")
          parsablerf.write(p+",")
    
          print i['value']+' '+'-',
    
    
        tag6= soup.select("#txtGP3")
        for i in tag6 :#pcd
          # i is a tag
          p=i['value']
          resultfile.write(p+"\t")
          parsablerf.write(p+",")
    
          print i['value']+' '+'-',
    
    
        tag7= soup.select("#txtGP4")
        for i in tag7 :#cad
          # i is a tag
          p=i['value']
          resultfile.write(p+"\t")
          parsablerf.write(p+",")
    
          print i['value']+' '+'-',
    
    
        tag8= soup.select("#txtGP5")
        for i in tag8 :#basic elec
          # i is a tag
          p=i['value']
          resultfile.write(p+"\t")
          parsablerf.write(p+",")
    
          print i['value']+' '+'-',
    
    
        tag9= soup.select("#txtGP6")
        for i in tag9 :#pcd lab
          # i is a tag
          p=i['value']
          resultfile.write(p+"\t")
          parsablerf.write(p+",")
    
          print i['value']+' '+'-',
    
    
        tag10= soup.select("#txtGP7")
        for i in tag10 :#chemlab
          # i is a tag
          p=i['value']
          resultfile.write(p+"\t")
          parsablerf.write(p+",")
    
          print i['value']+' '+'-',
    
    
        tag3=soup.select("#lblSGPA")
        for i in tag3 :
          # i is a tag
          p=i.string
          resultfile.write(p+"\n")
          parsablerf.write(p+"\n")
    
          print "SGPA="+i.string,
    
        print("\n")
    except :
        return

    
    
def main():
    branches = ["cs","is","ec","me"]
    for the_branch in branches :
        urlstrings = url_generator(the_branch)
        
        try :
            filename = the_branch+".txt"
            parsablefilename = the_branch+"_par.txt"
            resultfile=open(filename,"a")
            parsablerf=open(parsablefilename,"a")
            
            """ open the webpage"""
            for i in urlstrings:
                
                count =4
                while(count>0):
                    
                    try:
                        print i
                        
                        file1=urllib2.urlopen(i)
                        soup=BeautifulSoup(file1,'lxml')
                        print i
                        try:
                            parser(soup,resultfile,parsablerf)
                        except Exception as p:
                            print "something wrong in calling parser"
                        
                        break
                    except urllib2.HTTPError as e:
                        count-=1
                        time.sleep(5)
                        pass
                
            
        
        except Exception as e :
            print e
            
        finally :
            resultfile.close()
            parsablerf.close()
        
    

if __name__ == '__main__':
    main()

